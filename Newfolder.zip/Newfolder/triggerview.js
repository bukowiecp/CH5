var pages = document.getElementById("pages");
var home = document.getElementById("home");
var media = document.getElementById("media");
var lights = document.getElementById("lights");
var climate = document.getElementById("climate");
var shades = document.getElementById("shades");
var security = document.getElementById("security");
var settings = document.getElementById("settings");

home.addEventListener("click", function () {
  pages.setActiveView(0);
});
media.addEventListener("click", function () {
  pages.setActiveView(1);
});
lights.addEventListener("click", function () {
  pages.setActiveView(2);
});
climate.addEventListener("click", function () {
  pages.setActiveView(3);
});
shades.addEventListener("click", function () {
  pages.setActiveView(4);
});
security.addEventListener("click", function () {
  pages.setActiveView(5);
});
settings.addEventListener("click", function () {
  pages.setActiveView(6);
});
